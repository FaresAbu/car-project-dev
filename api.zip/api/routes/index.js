var express = require('express');
var router = express.Router();
const collection = require('../config')
router.get('/cars', (req, res, next) => {
  req.collection.find({})
    .toArray()
    .then(results => res.json(results))
    .catch(err => res.send(err));
});


module.exports = router
