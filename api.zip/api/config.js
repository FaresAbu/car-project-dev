module.exports = {
    dbHost: 'localhost',
    dbName: 'vehicle-view',
    collectionName: 'vehicles',
    sourceDataFile: 'data.txt',
}